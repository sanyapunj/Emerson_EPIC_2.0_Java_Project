import React, { useState } from "react";
import EmployeeForm from "./components/EmployeeForm";
import EmployeeList from "./components/EmployeeList";
import EmployeeDetails from "./components/EmployeeDetails";

function App() {
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [viewEmployee, setViewEmployee] = useState(null);

  return (
   <div
     style={{
       maxWidth: "1100px",
       margin: "0 auto",
       padding: "40px 30px",
       fontFamily: "Segoe UI, sans-serif",
       backgroundColor: "#f6f8fc",
       minHeight: "100vh"
     }}
   >
     <h1
       style={{
         textAlign: "center",
         fontSize: "36px",
         fontWeight: "800",
         marginBottom: "30px",
         color: "#2b2d42",
         letterSpacing: "1px"
       }}
     >
       Employee Management System
     </h1>



     <EmployeeForm
       selectedEmployee={selectedEmployee}
       onCancel={() => setSelectedEmployee(null)}
     />


      <EmployeeList
        onEdit={(emp) => {
          setSelectedEmployee(emp);
          setViewEmployee(null);
        }}
        onView={(emp) => {
          setViewEmployee(emp);
          setSelectedEmployee(null);
        }}
      />

      <EmployeeDetails
        employee={viewEmployee}
        onClose={() => setViewEmployee(null)}
      />
    </div>
  );

}

export default App;
