import React from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";

function EmployeeDetails({ employee, onClose }) {
  const queryClient = useQueryClient();

  const deleteEmployee = useMutation({
    mutationFn: (id) =>
      axios.delete(`http://localhost:8080/api/employees/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries(["employees"]);
      onClose();
    },
  });

  if (!employee) return null;

  return (
    <div
      style={{
        marginTop: "30px",
        padding: "20px",
        borderRadius: "10px",
        backgroundColor: "#ffffff",
        boxShadow: "0 4px 10px rgba(0,0,0,0.1)"
      }}
    >
      <h2 style={{ color: "#1976d2", marginBottom: "15px" }}>
        Employee Details
      </h2>

      <p><strong>ID:</strong> {employee.id}</p>
      <p><strong>Name:</strong> {employee.name}</p>
      <p><strong>Email:</strong> {employee.email}</p>
      <p><strong>Salary:</strong> ₹{employee.salary}</p>

      <div style={{ marginTop: "20px" }}>
        <button
          onClick={() => deleteEmployee.mutate(employee.id)}
          style={{
            backgroundColor: "#d32f2f",
            color: "#fff",
            padding: "8px 14px",
            border: "none",
            borderRadius: "5px",
            marginRight: "10px",
            cursor: "pointer"
          }}
        >
          Delete
        </button>

        <button
          onClick={onClose}
          style={{
            backgroundColor: "#9e9e9e",
            color: "#fff",
            padding: "8px 14px",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer"
          }}
        >
          Close
        </button>
      </div>
    </div>
  );
}

export default EmployeeDetails;
