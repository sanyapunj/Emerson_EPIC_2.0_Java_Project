import React, { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";

function EmployeeForm({ selectedEmployee, onCancel }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [salary, setSalary] = useState("");

  const queryClient = useQueryClient();

  useEffect(() => {
    if (selectedEmployee) {
      setName(selectedEmployee.name);
      setEmail(selectedEmployee.email);
      setSalary(selectedEmployee.salary);
    } else {
      setName("");
      setEmail("");
      setSalary("");
    }
  }, [selectedEmployee]);

  const saveEmployee = useMutation({
    mutationFn: (employee) => {
      if (employee.id) {
        return axios.put(
          `http://localhost:8080/api/employees/${employee.id}`,
          employee
        );
      }
      return axios.post("http://localhost:8080/api/employees", employee);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["employees"]);
      setName("");
      setEmail("");
      setSalary("");
      onCancel && onCancel();
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();

    saveEmployee.mutate({
      id: selectedEmployee?.id,
      name,
      email,
      salary
    });
  };

  return (
    <div
      style={{
        backgroundColor: "#f8f9ff",
        padding: "25px",
        borderRadius: "12px",
        marginBottom: "30px",
        boxShadow: "0 4px 10px rgba(0,0,0,0.1)"
      }}
    >
      <h2 style={{ marginBottom: "20px", color: "#3f3d56" }}>
        {selectedEmployee ? "Update Employee" : "Add Employee"}
      </h2>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Name"
          value={name}
          autoComplete="off"
          data-lpignore="true"
          onChange={(e) => setName(e.target.value)}
          required
          style={inputStyle}
        />

        <input
          type="email"
          placeholder="Email"
          value={email}
          autoComplete="off"
          data-lpignore="true"
          onChange={(e) => setEmail(e.target.value)}
          required
          style={inputStyle}
        />

        <input
          type="number"
          placeholder="Salary"
          value={salary}
          autoComplete="off"
          data-lpignore="true"
          onChange={(e) => setSalary(e.target.value)}
          required
          style={inputStyle}
        />

        <button style={primaryButton} type="submit">
          {selectedEmployee ? "Update Employee" : "Add Employee"}
        </button>

        {selectedEmployee && (
          <button
            type="button"
            onClick={onCancel}
            style={secondaryButton}
          >
            Cancel Update
          </button>
        )}
      </form>
    </div>
  );
}

/* ---------- Styles ---------- */

const inputStyle = {
  width: "100%",
  padding: "10px",
  marginBottom: "12px",
  borderRadius: "6px",
  border: "1px solid #ccc"
};

const primaryButton = {
  width: "100%",
  padding: "10px",
  backgroundColor: "#6c63ff",
  color: "white",
  border: "none",
  borderRadius: "8px",
  cursor: "pointer",
  marginBottom: "10px",
  fontWeight: "bold"
};

const secondaryButton = {
  width: "100%",
  padding: "10px",
  backgroundColor: "#ddd",
  color: "#333",
  border: "none",
  borderRadius: "8px",
  cursor: "pointer"
};

export default EmployeeForm;
