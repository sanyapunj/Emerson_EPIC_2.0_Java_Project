import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";

const fetchEmployees = async () => {
  const response = await axios.get("http://localhost:8080/api/employees");
  return response.data;
};

function EmployeeList({ onEdit, onView }) {
  const { data: employees = [], isLoading, error } = useQuery({
    queryKey: ["employees"],
    queryFn: fetchEmployees,
  });

  const [search, setSearch] = useState("");
  const [salaryFilter, setSalaryFilter] = useState("ALL");

  if (isLoading) return <p>Loading employees...</p>;
  if (error) return <p>Error loading employees</p>;

  const filteredEmployees = employees.filter((emp) => {
    const matchesSearch =
      emp.name.toLowerCase().includes(search.toLowerCase()) ||
      emp.email.toLowerCase().includes(search.toLowerCase());

    const matchesSalary =
      salaryFilter === "ALL" ||
      (salaryFilter === "LOW" && emp.salary < 50000) ||
      (salaryFilter === "MID" &&
        emp.salary >= 50000 &&
        emp.salary <= 100000) ||
      (salaryFilter === "HIGH" && emp.salary > 100000);

    return matchesSearch && matchesSalary;
  });

  return (
    <div
      style={{
        backgroundColor: "#ffffff",
        padding: "25px",
        borderRadius: "14px",
        boxShadow: "0 8px 20px rgba(46,196,182,0.12)",
        marginBottom: "35px"
      }}
    >

      <h3>Employee List</h3>

      {/* Search & Filter */}
      <div style={{ display: "flex", gap: "10px", marginBottom: "15px" }}>
        <input
          type="text"
          placeholder="Search by name or email"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ flex: 1, padding: "8px" }}
        />

        <select
          value={salaryFilter}
          onChange={(e) => setSalaryFilter(e.target.value)}
          style={{ padding: "8px" }}
        >
          <option value="ALL">All Salaries</option>
          <option value="LOW">Below 50k</option>
          <option value="MID">50k – 100k</option>
          <option value="HIGH">Above 100k</option>
        </select>
      </div>

      {/* Employee Table */}
      <table
        width="100%"
        border="1"
        cellPadding="8"
        style={{ borderCollapse: "collapse" }}
      >
       <thead style={{ backgroundColor: "#4f7cff", color: "#fff" }}>

          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {filteredEmployees.length === 0 ? (
            <tr>
              <td colSpan="3" align="center">
                No employees found
              </td>
            </tr>
          ) : (
            filteredEmployees.map((emp) => (
              <tr key={emp.id}>
                <td>{emp.id}</td>
                <td>{emp.name}</td>
                <td>
                  <button
                  onClick={() => onEdit(emp)}
                    style={{
                      backgroundColor: "#2ec4b6",
                      color: "#fff",
                      border: "none",
                      padding: "6px 10px",
                      borderRadius: "6px",
                      cursor: "pointer",
                      marginRight: "8px"
                    }}
                  >
                    Edit
                  </button>

                  <button
                  onClick={() => onView(emp)}
                    style={{
                      backgroundColor: "#4f7cff",
                      color: "#fff",
                      border: "none",
                      padding: "6px 10px",
                      borderRadius: "6px",
                      cursor: "pointer"
                    }}
                  >
                    View more details
                  </button>

                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default EmployeeList;
