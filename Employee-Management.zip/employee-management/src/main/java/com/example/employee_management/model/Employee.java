package com.example.employee_management.model;

import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.UUID;

@Table("employees")
public class Employee {

    @PrimaryKey
    private UUID id;
    private String name;
    private String email;
    private double salary;

    public Employee() {}

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {   // ✅ THIS MUST EXIST
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}
