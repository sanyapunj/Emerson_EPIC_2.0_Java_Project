package com.example.employee_management.repository;

import com.example.employee_management.model.Employee;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.UUID;

public interface EmployeeRepository extends CassandraRepository<Employee, UUID> {
}
