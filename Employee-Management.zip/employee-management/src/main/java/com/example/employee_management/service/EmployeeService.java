package com.example.employee_management.service;

import com.example.employee_management.model.Employee;
import com.example.employee_management.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class EmployeeService {

    private final EmployeeRepository repository;

    public EmployeeService(EmployeeRepository repository) {
        this.repository = repository;
    }

    public Employee create(Employee employee) {
        employee.setId(UUID.randomUUID()); // ✅ NOW IT WILL WORK
        return repository.save(employee);
    }

    public List<Employee> getAll() {
        return repository.findAll();
    }
    public Employee getById(UUID id) {
        return repository.findById(id).orElse(null);
    }

    public Employee update(UUID id, Employee updatedEmployee) {
        Employee existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        existing.setName(updatedEmployee.getName());
        existing.setEmail(updatedEmployee.getEmail());
        existing.setSalary(updatedEmployee.getSalary());

        return repository.save(existing);
    }


    public void delete(UUID id) {
        repository.deleteById(id);
    }

}
